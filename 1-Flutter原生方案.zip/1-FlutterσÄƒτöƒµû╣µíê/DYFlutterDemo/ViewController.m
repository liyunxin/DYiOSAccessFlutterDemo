//
//  ViewController.m
//  DYFlutterDemo
//
//  Created by Lambert on 2021/11/18.
//

#import "ViewController.h"
#import <Flutter/Flutter.h>
#import <FlutterPluginRegistrant/GeneratedPluginRegistrant.h>
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    FlutterViewController *flutterCon = [[FlutterViewController alloc] initWithProject:nil initialRoute:@"route1" nibName:nil bundle:nil];
    [GeneratedPluginRegistrant registerWithRegistry:flutterCon];
    [self.navigationController pushViewController:flutterCon animated:YES];
}

@end
