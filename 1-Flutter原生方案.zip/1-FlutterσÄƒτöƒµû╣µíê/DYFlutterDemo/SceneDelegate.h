//
//  SceneDelegate.h
//  DYFlutterDemo
//
//  Created by Lambert on 2021/11/18.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

